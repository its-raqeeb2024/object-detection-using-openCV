# object_tracking
Easy OpenCV Python Object Tracking Application using selectROI
